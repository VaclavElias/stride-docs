﻿using System.Threading.Tasks;
using SiliconStudio.Core;
using SiliconStudio.Xenko.Input;
using SiliconStudio.Xenko.Engine;
using SiliconStudio.Xenko.UI;
using SiliconStudio.Xenko.UI.Controls;
using XboxLiveSample.Core;

namespace XboxLiveSample
{
    public class LoginScript : AsyncScript
    {
        public UIComponent UI { get; set; }
        private TextBlock usernameBlock;
        private TextBlock signinBlock;
        private TextBlock statusMessage;
        private bool signedIn;

        // Declared public member fields and properties will show in the game studio
        private IConnectedAccount account;

        public override async Task Execute()
        {
            // Prepare the HUD
            if (UI != null)
            {
                usernameBlock   = UI.Page?.RootElement?.FindVisualChildOfType<TextBlock>("Username");
                signinBlock     = UI.Page?.RootElement?.FindVisualChildOfType<TextBlock>("SignIn");
                statusMessage   = UI.Page?.RootElement?.FindVisualChildOfType<TextBlock>("Status");
            }

            var accountMgr = Services.GetServiceAs<IAccountManager>();

            account = accountMgr?.CreateConnectedAccount();
            if (account == null)
            {
                // No account manager was found or creating account failed.
                //  We can't display any user information at this point
                if (usernameBlock != null)   usernameBlock.Text = "Unknown user";
                if (signinBlock != null)     signinBlock.Text = "";
                if (statusMessage != null) statusMessage.Text = "";
                return;
            }

            AccountChanged(await account.LoginSilentlyAsync());

            while (Game.IsRunning)
            {
                if (signedIn)
                {
                    // Switch user
                    if (Input.IsKeyDown(Keys.Y) || Input.IsGamePadButtonDownAny(GamePadButton.Y))
                    {
                        AccountChanged(await account.SwitchAccount());
                    }
                }
                else
                {
                    // Log in
                    if (Input.IsKeyDown(Keys.A) || Input.IsGamePadButtonDownAny(GamePadButton.A))
                    {
                        AccountChanged(await account.LoginSilentlyAsync());
                    }
                }

                // Do stuff every new frame
                await Script.NextFrame();
            }
        }

        private void AccountChanged(SignInStatus status)
        {
            if (status != SignInStatus.Success)
            {
                if (statusMessage != null && status == SignInStatus.UserCancel) statusMessage.Text = "User cancel";
                if (statusMessage != null && status == SignInStatus.UserInteractionRequired) statusMessage.Text = "User interaction required";
                if (usernameBlock != null) usernameBlock.Text = "Signed out";
                return;
            }

            signedIn = account.IsSignedIn();
            if (signedIn)
            {
                if (signinBlock != null) signinBlock.Text = "Y: Switch user";
            }
            else
            {
                if (signinBlock != null) signinBlock.Text = "A: Sign in";
            }

            if (usernameBlock != null) usernameBlock.Text = account.Username();
        }
    }
}
