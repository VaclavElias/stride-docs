﻿
namespace XboxLiveSample
{
    public interface IAccountManager
    {
        IConnectedAccount CreateConnectedAccount();

        string ServiceName();
    }
}
