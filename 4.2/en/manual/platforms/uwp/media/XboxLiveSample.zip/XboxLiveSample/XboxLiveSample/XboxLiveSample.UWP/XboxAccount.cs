﻿using System;
using System.Threading.Tasks;
using Microsoft.Xbox.Services.System;

namespace XboxLiveSample
{
    public class XboxAccount : IConnectedAccount
    {
        private XboxLiveUser xboxUser;

        public XboxAccount()
        {
            xboxUser = new XboxLiveUser();
        }

        public async Task<SignInStatus> LoginAsync()
        {
            var coreDispatcher = Windows.ApplicationModel.Core.CoreApplication.GetCurrentView().CoreWindow.Dispatcher;

            var result = await xboxUser.SignInAsync(coreDispatcher);

            return (SignInStatus)result.Status;
        }

        public async Task<SignInStatus> LoginSilentlyAsync()
        {
            var coreDispatcher = Windows.ApplicationModel.Core.CoreApplication.GetCurrentView().CoreWindow.Dispatcher;

            var result = await xboxUser.SignInSilentlyAsync(coreDispatcher);

            return (SignInStatus)result.Status;
        }

        public async Task<SignInStatus> SwitchAccount()
        {
            var coreDispatcher = Windows.ApplicationModel.Core.CoreApplication.GetCurrentView().CoreWindow.Dispatcher;

            var result = await xboxUser.SwitchAccountAsync(coreDispatcher);

            return (SignInStatus)result.Status;
        }

        public string Username()
        {
            return xboxUser.Gamertag;
        }

        public bool IsSignedIn()
        {
            return xboxUser.IsSignedIn;
        }
    }
}
