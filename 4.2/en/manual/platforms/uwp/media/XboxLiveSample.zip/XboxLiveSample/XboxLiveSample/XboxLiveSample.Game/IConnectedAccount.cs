﻿using System.Threading.Tasks;

namespace XboxLiveSample
{
    public enum SignInStatus
    {
        Success = 0,
        UserInteractionRequired = 1,
        UserCancel = 2
    }

    public interface IConnectedAccount
    {
        Task<SignInStatus> LoginAsync();

        Task<SignInStatus> LoginSilentlyAsync();

        Task<SignInStatus> SwitchAccount();

        string Username();

        bool IsSignedIn();
    }
}
