﻿
namespace XboxLiveSample
{
    public class XboxLiveAccountManager : IAccountManager
    {
        public string ServiceName() => "xboxlive";

        public IConnectedAccount CreateConnectedAccount()
        {
            return new XboxAccount();
        }
    }
}
